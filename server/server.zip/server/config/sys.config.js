module.exports = {
  BAIDU: {
    APP_ID: "18937312",
    API_KEY: "BxenLUbxYGtt2MUUcc7GrGX6",
    SECRET_KEY: "aKgx7OQDp74qWOR43OZfj9BrgolQ4HRI",
  },
  // CHROMEPATH: "/home/wwwroot/crawle.lajitoutiao.top/chromedriver",
  CHROMEPATH:
    "/Users/mark/Desktop/Google Chrome.app/Contents/MacOS/Google Chrome",
};
