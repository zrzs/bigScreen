﻿// $(window).load(function () {
//   $(".tab-item").click((e) => {
//     var id = $(e.currentTarget).attr("id");
//     $(e.currentTarget).addClass("tab-item-select");
//     $(".screen-box").hide();
//     $("." + id).show();
//   });
//   setTimeout(() => {
//     $(".loading").fadeOut();
//   }, 2000);
// });

// /****/
// $(document).ready(function () {
//   setTimeout(() => {
//     $(".loading").fadeOut();
//   }, 5000);
// });
