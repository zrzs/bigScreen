"use strict";

exports.mysql = {
  enable: true,
  package: "egg-mysql"
};
