"use strict";

/**
 * @param {Egg.Application} app - egg application
 */
module.exports = (app) => {
  const { router, controller } = app;
  router.get("/", controller.home.index);
  router.get("/crawlMonthconInfo", controller.home.crawlMonthconInfo);
  router.get("/crawlMonthconDetailInfo", controller.home.crawlMonthconDetailInfo);
  router.get("/crawlBrandInfo", controller.home.crawlBrandInfo);
  router.get("/getChartData", controller.home.getChartData);
};
