"use strict";

const request = require("request");

const iconv = require("iconv-lite");
var CronJob = require("cron").CronJob;
const xlsx = require("node-xlsx");
const path = require("path");

const Controller = require("egg").Controller;

const AipOcrClient = require("baidu-aip-sdk").ocr;
var fs = require("fs");

// 设置APPID/AK/SK
const APP_ID = "18937312";
const API_KEY = "BxenLUbxYGtt2MUUcc7GrGX6";
const SECRET_KEY = "aKgx7OQDp74qWOR43OZfj9BrgolQ4HRI";

// 新建一个对象，建议只保存一个对象调用服务接口
const client = new AipOcrClient(APP_ID, API_KEY, SECRET_KEY);

class HomeController extends Controller {
  async index() {
    const { ctx } = this;
    // https://k.autohome.com.cn/264
    request(
      { url: "https://k.autohome.com.cn/264", encoding: null,
      },
      async (error, response, body) => {
        fs.writeFile('brand.html', iconv.decode(body, "gb2312"),  function(err) {
          if (err) {
              return console.error(err);
          }
       });
      }
    );

    // const user = await ctx.service.user.get(1);

    // await ctx.service.spider.crawlMouthconDetailList();//更新车型后采集的字段
    // await ctx.service.spider.getMouthconListByBrand(); //爬取口碑详情

    // const base64 = await ctx.service.spider.getAutoMouthconInfo(
    //   "1195625-0",
    //   "https://k.autohome.com.cn/detail/view_01ccgv5d9w68r32c9q60s00000.html?st=2162&piap=0|3170|0|0|1|0|0|0|0|0|1#pvareaid=2112108"
    // );

    // console.log(baiduResult);

    ctx.body = "hi, egg.js home page";
  }

  async crawlMonthconInfo() {
    const job = new CronJob(
      "*/20 * * * * *",
      async () => {
        await this.ctx.service.spider.getUnCrawlAutoMouthconList();
      },
      null,
      true, 
      "Asia/Chongqing"
    );
    
    this.ctx.body = "正在抓取口碑信息中....";
  }

  async crawlMonthconDetailInfo() {
    const brandList= await this.ctx.service.spider.getWaitingCrawlMouthconDetailList();
    if(brandList.length<=0){
      return "暂无待爬取的口碑信息";
    }
    let cursor=0;
    let crawlerInfo={url:cursor===1916?'https://k.autohome.com.cn/530/StopSelling/index_204.html': brandList[cursor].modelMouthcon,end:false};
    const job = new CronJob(
      "*/3 * * * * *",
      async () => {
        if (cursor===brandList.length-1) {
          job.stop();
          console.log("口碑数据数据爬取完成");
        } else {
          try {
            console.log(crawlerInfo,cursor);
          crawlerInfo=await this.ctx.service.spider.crawlMouthconList(crawlerInfo.url,brandList[cursor]);
          console.log("after:",crawlerInfo,cursor);
          if(crawlerInfo.end){
            cursor=cursor+1;
            crawlerInfo={url:brandList[cursor].modelMouthcon,end:false};
           }
          } catch (error) {
            console.log(error);
          }
        }
      },
      null,
      true, 
      "Asia/Chongqing"
    );
    this.ctx.body = "正在抓取口碑详情信息中....";
  }

  async crawlBrandInfo() {
   const brandList= await this.ctx.service.spider.getWaitingCrawlMouthconDetailList();
    if(brandList.length<=0){
      return "暂无待爬取的车型数据";
    }
    let cursor=0;
    // 创建定时任务每3秒 爬取一次车型数据
    const job = new CronJob(
      "*/3 * * * * *",
      async () => {
        if (cursor===brandList.length-1) {
          job.stop();
          console.log("车型数据爬取完成");
        } else {
          try {
            const brand=brandList[cursor];
            await this.ctx.service.spider.getModelDetaiInfoByURL(brand);
            cursor=cursor+1;
          } catch (error) {
            console.log(error);
          }
        }
      },
      null,
      true,
      "Asia/Chongqing"
    );
    this.ctx.body = "车型数据爬取中....";
  }

  async getChartData() {
   const auctionList=await this.ctx.service.auction.getAuctionList();

    let data_1_1 = xlsx.parse(path.join("xlsx", "1-1.xlsx"));
    let data_1_2 = xlsx.parse(path.join("xlsx", "1-2.xlsx"));
    let data_1_3 = xlsx.parse(path.join("xlsx", "1-3.xlsx"));
    let data_1_4 = xlsx.parse(path.join("xlsx", "1-4.xlsx"));
    let data_1_5 = xlsx.parse(path.join("xlsx", "1-5.xlsx"));
    let data_1_6 = xlsx.parse(path.join("xlsx", "1-6.xlsx"));

    let data_2_1 = xlsx.parse(path.join("xlsx", "2-1.xlsx"));
    let data_2_2 = xlsx.parse(path.join("xlsx", "2-2.xlsx"));
    let data_2_3 = xlsx.parse(path.join("xlsx", "2-3.xlsx"));
    let data_2_4 = xlsx.parse(path.join("xlsx", "2-4.xlsx"));
    let data_2_5 = xlsx.parse(path.join("xlsx", "2-5.xlsx"));
    let data_2_6 = xlsx.parse(path.join("xlsx", "2-6.xlsx"));

    let data_3_1 = xlsx.parse(path.join("xlsx", "3-1.xlsx"));
    let data_3_2 = xlsx.parse(path.join("xlsx", "3-2.xlsx"));
    let data_3_3 = xlsx.parse(path.join("xlsx", "3-3.xlsx"));
    let data_3_4 = xlsx.parse(path.join("xlsx", "3-4.xlsx"));
    let data_3_5 = xlsx.parse(path.join("xlsx", "3-5.xlsx"));
    let data_3_6 = xlsx.parse(path.join("xlsx", "3-6.xlsx"));

    this.ctx.body = {
      data_1_1,data_1_2,data_1_3,data_1_4,data_1_5,data_1_6,
      data_2_1,data_2_2,data_2_3,data_2_4,data_2_5,data_2_6,
      data_3_1,data_3_2,data_3_3,data_3_4,data_3_5,data_3_6,  
      auctionList
    };
  }
}

module.exports = HomeController;
